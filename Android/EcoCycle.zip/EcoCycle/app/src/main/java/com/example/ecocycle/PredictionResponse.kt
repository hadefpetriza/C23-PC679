package com.example.ecocycle

data class PredictionResponse(
    val prediction: String
)
