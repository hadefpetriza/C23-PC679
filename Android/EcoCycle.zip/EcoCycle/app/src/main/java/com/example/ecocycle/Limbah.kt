package com.example.ecocycle

data class Limbah(
    val alamat: String = "",
    val image: String = "",
    val judul: String = "",
    val deskripsi: String = ""
)
