package com.example.ecocycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.android.volley.Request
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.ecocycle.databinding.ActivityMapsBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLngBounds

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setTitle("Lokasi Tempat Sampah")

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val url = "https://ecocycle-backend-dxgtigjrgq-et.a.run.app/maps"
        val requestQueue = Volley.newRequestQueue(this)
        val request = JsonObjectRequest(Request.Method.GET, url, null,
            { response ->
        
                val places = response.getJSONArray("places")
                for (i in 0 until places.length()) {
                    val place = places.getJSONObject(i)
                    val latitude = place.getDouble("latitude")
                    val longitude = place.getDouble("longitude")
                    val name = place.getString("name")

                    val location = LatLng(latitude, longitude)
                    mMap.addMarker(MarkerOptions().position(location).title(name))
                }

                val boundsBuilder = LatLngBounds.builder()
                for (i in 0 until places.length()) {
                    val place = places.getJSONObject(i)
                    val latitude = place.getDouble("latitude")
                    val longitude = place.getDouble("longitude")
                    boundsBuilder.include(LatLng(latitude, longitude))
                }
                val bounds = boundsBuilder.build()
                mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))
            },
            { error ->
                Log.e("MapsActivity", "Error: ${error.message}")
            }
        )
        requestQueue.add(request)

    }
}