package com.example.ecocycle

data class UploadResponse(
    val status: String,
    val imageUrl: String
)
