package com.example.ecocycle

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.ecocycle.databinding.ActivityPrediksiBinding
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class PrediksiActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPrediksiBinding
    private lateinit var tflite: Interpreter
    private var pilihGambar: Bitmap? = null

    companion object {
        private const val AMBIL_GAMBAR = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrediksiBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setTitle("Prediksi Limbah")

        binding.ivPredictLimbah.setOnClickListener{
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, AMBIL_GAMBAR)
        }

        binding.btnPredictLimbah.setOnClickListener{
            if (pilihGambar!= null) {
                predictWaste(pilihGambar!!)
            } else {
                Toast.makeText(this, "Pilih gambar terlebih dahulu", Toast.LENGTH_SHORT).show()
            }
        }
        try {
            tflite = Interpreter(loadModelFile())
        } catch (e: IOException) {
            e.printStackTrace()
        }

        binding.mapsPredictLimbah.setOnClickListener{
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tflite.close()
    }

    private fun loadModelFile(): MappedByteBuffer {
        val modelPath = "model.tflite"
        val assetManager = assets
        val fileDescriptor = assetManager.openFd(modelPath)
        val fileInputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = fileInputStream.channel
        val startOffset: Long = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    private fun predictWaste(bitmap: Bitmap) {
        if (!::tflite.isInitialized) {
            Toast.makeText(this, "Model TFLite belum dimuat", Toast.LENGTH_SHORT).show()
            return
        }

        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
        val inputBuffer = ByteBuffer.allocateDirect(224 * 224 * 3 * 4)
        inputBuffer.order(ByteOrder.nativeOrder())
        inputBuffer.rewind()
        for (y in 0 until 224) {
            for (x in 0 until 224) {
                val pixel = resizedBitmap.getPixel(x, y)
                inputBuffer.putFloat(((pixel shr 16) and 0xFF) / 255.0f)
                inputBuffer.putFloat(((pixel shr 8) and 0xFF) / 255.0f)
                inputBuffer.putFloat((pixel and 0xFF) / 255.0f)
            }
        }

        val output = Array(1) { FloatArray(5) }
        tflite.run(inputBuffer, output)


        val probabilities = output[0]
        val labels = arrayOf("Sampah organic", "Sampah plastic", "Sampah kayu", "Sampah besi", "Non recycle")
        var maxIndex = 0
        var maxPeluang = 0.0f
        for (i in probabilities.indices) {
            if (probabilities[i] > maxPeluang) {
                maxIndex = i
                maxPeluang = probabilities[i]
            }
        }
        val predictedLabel = labels[maxIndex]

        binding.resultPrediksi.text = "$predictedLabel"

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == AMBIL_GAMBAR && resultCode == RESULT_OK) {
            if (data != null) {
                val selectedImageUri = data.data
                pilihGambar = BitmapFactory.decodeStream(selectedImageUri?.let {
                    contentResolver.openInputStream(
                        it
                    )
                })
                binding.ivPredictLimbah.setImageBitmap(pilihGambar)
            }
        }
    }
}