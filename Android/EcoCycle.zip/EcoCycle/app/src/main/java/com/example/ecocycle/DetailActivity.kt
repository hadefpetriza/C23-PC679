package com.example.ecocycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.ecocycle.databinding.ActivityDetailBinding
import com.google.firebase.firestore.FirebaseFirestore

class DetailActivity : AppCompatActivity() {
    private lateinit var binding : ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val limbahId = intent.getStringExtra("limbahId")
        val db = FirebaseFirestore.getInstance()
        val limbahRef = limbahId?.let { db.collection("limbah").document(it) }

        limbahRef?.get()?.addOnCompleteListener {task->
            if (task.isSuccessful) {
                val document = task.result
                if (document.exists()) {
                    val alamat = document.getString("alamat")
                    val image = document.getString("image")
                    val judul = document.getString("judul")
                    val deskripsi = document.getString("deskripsi")

                    Glide.with(this)
                        .load(image)
                        .into(binding.ivDetailLimbah)

                    binding.judulDetailLimbah.text = judul
                    binding.alamatDetailLimbah.text = alamat
                    binding.deskripsiDetailLimbah.text = deskripsi
                }
            }
        }


    }

}